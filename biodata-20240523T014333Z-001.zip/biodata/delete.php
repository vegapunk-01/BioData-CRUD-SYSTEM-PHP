<?php 
    if ( isset($_GET["id"]) ) {
        $id = $_GET["id"];

        $servername ="localhost";
        $username ="root";
        $password ="";
        $database ="db_biodata";

        $connection = new mysqli($servername, $username, $password, $database);

        $sql = "DELETE FROM tb_data WHERE id=$id";
        $connection->query($sql);
    }

    header("location: /biodata/index.php");
    exit;
?>