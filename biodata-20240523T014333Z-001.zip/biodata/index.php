<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bio Data</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-5">
        <h2>List of Applicants</h2>
        <br>
        <a class="btn btn-primary" href="/biodata/create.php" role="button">New Applicant</a>
        <br><br>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Position Desired</th>
                    <th>Name</th>
                    <th>Gender</th>
                    <th>Age</th>
                    <th>Birthdate</th>
                    <th>Phone</th>
                    <th>Email</th>
                    <th>Address</th>
                    <th>Civil Status</th>
                    <th>Citizenship</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $servername ="localhost";
                $username ="root";
                $password ="";
                $database ="db_biodata";

                //create connection 
                $connection = new mysqli($servername, $username, $password, $database);

                if ($connection->connect_error) {
                    die("Connection Failed: " . $connection->connect_error);
                }

                //read all row from the database table
                $sql = "SELECT * FROM tb_data";
                $result = $connection->query($sql);

                if (!$result) {
                    die("Invalid Query: " . $connection->connect_error);
                }

                //read data each row
                while($row =$result->fetch_assoc()) {
                    echo "<tr>
                    <td>$row[id]</td>
                    <td>$row[position]</td>
                    <td>$row[name]</td>
                    <td>$row[gender]</td>
                    <td>$row[age]</td>
                    <td>$row[birthdate]</td>
                    <td>$row[phone]</td>
                    <td>$row[email]</td>
                    <td>$row[address]</td>
                    <td>$row[civilstatus]</td>
                    <td>$row[citizenship]</td>
                    <td>
                        <a class='btn btn-primary btn-sm' href='/biodata/edit.php?id=$row[id]'>EDIT</a>
                        <a class='btn btn-danger btn-sm' href='/biodata/delete.php?id=$row[id]'>DELETE</a>
                    </td>
                </tr>
                    ";
                }
                ?>
                
            </tbody>
        </table>

    </div>
</body>
</html>